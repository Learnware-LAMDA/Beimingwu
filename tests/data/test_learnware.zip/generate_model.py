
import joblib
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn import svm
import os

X,y = load_digits(return_X_y=True)
data_X, _, data_y, _ = train_test_split(X, y, test_size=0.3, shuffle=True)

# input dimension: (64, ), output dimension: (10, )
clf = svm.SVC(kernel="linear", probability=True)
clf.fit(data_X, data_y)

joblib.dump(clf, "svm.pkl") # model is stored as file "svm.pkl"


import learnware.specification as specification

# generate rkme specification for digits dataset
spec = specification.utils.generate_rkme_spec(X=data_X, gamma=0.1, cuda_idx=0)
spec.save(os.path.join("stat.json"))