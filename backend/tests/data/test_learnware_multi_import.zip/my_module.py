
from .my_module2 import *

class MyClass():
    pass
