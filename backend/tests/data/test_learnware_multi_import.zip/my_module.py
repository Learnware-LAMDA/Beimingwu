
import my_module2

class MyClass():
    pass
