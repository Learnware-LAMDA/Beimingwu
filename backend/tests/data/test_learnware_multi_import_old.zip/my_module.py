

class MyClass():
    pass
